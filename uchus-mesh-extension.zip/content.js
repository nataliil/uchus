/* «Учусь» — автоматический перенос домашки из МЭШ.
   Работает сам: открыли дневник — домашка уже в приложении.
   Ничего не отправляет в интернет, пароль не хранит. */

(function () {
  var APP = 'https://nataliil.github.io/uchus/';
  var ID = 'uchus-mesh-btn';
  var NL = String.fromCharCode(10);

  var SUBJECT_RE = /(алгебр|геометр|физическ(ая)? культура|физик|биолог|француз|франц|англ|иностранный|русск|литератур|истор|обществ|географ|информатик|вероятность|статистик)/i;
  var NOISE = [
    /^перемена/i, /^\d{1,2}:\d{2}/, /каб\. ?№/i, /^\d+$/, /^h$/i,
    /материал(ы|а)? к дз/i, /^еще \d+/i, /^ещё \d+/i,
    /дополнительное образование/i, /внеурочная деятельность/i, /^группа /i,
    /раздел переехал/i, /список занятий/i, /^перейти$/i, /^о проекте$/i,
    /польз\. ?соглашение/i, /^\+7 \(\d{3}\)/i, /написать нам/i, /департамент/i,
    /^версия/i, /проектная деятельность/i, /друние занятия/i, /^друние/i,
    /^задания$/, /^домашние задания$/, /^оценки$/, /^учёба$/, /^школа$/, /^счета$/, /^личный кабинет$/i,
    /^день$/, /^шкала времени$/, /^больничный$/, /текущий дневник/i
  ];

  function collect() {
    var text = document.body ? (document.body.innerText || '') : '';
    var lines = text.split(NL).map(function (s) { return s.replace(/[ \t]+/g, ' ').trim(); });
    var recs = [], cur = null;

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (!line) continue;

      if (SUBJECT_RE.test(line) && !/^(домашнее|не хочу)/i.test(line)) {
        if (cur) recs.push(cur);
        cur = { subject: line, task: [], done: null };
        continue;
      }
      if (/^домашнее задание выполнено/i.test(line)) {
        if (cur) cur.done = true;
        continue;
      }
      if (/^домашнее задание/i.test(line)) {
        if (cur) cur.done = false;
        continue;
      }
      if (/^дополнительное/i.test(line) || /раздел переехал/i.test(line)) break;

      var noise = false;
      for (var j = 0; j < NOISE.length; j++) {
        if (NOISE[j].test(line)) { noise = true; break; }
      }
      if (noise) continue;

      if (cur && line.length > 1) cur.task.push(line);
    }
    if (cur) recs.push(cur);

    return recs
      .filter(function (r) {
        if (r.done === true) return false;                     // уже выполнено — в приложение не нужно
        var t = r.task.join(' ').toLowerCase();
        if (/^не задано\.?$/.test(t) || /^нет дз\.?$/.test(t)) return false;
        return r.task.length;
      })
      .map(function (r) {
        var prefix = r.subject.replace(/:$/, '');
        var status = r.done === true ? ' (выполнено)' : '';
        return prefix + ': ' + r.task.join('; ') + status;
      });
  }

  function buildPayload(list) {
    return btoa(unescape(encodeURIComponent(list.join(NL))));
  }

  function alreadySentToday() {
    var today = new Date().toISOString().slice(0, 10);
    try {
      if (localStorage.getItem('uchus_last_push') === today) return true;
      localStorage.setItem('uchus_last_push', today);
    } catch (e) {}
    return false;
  }

  function push(auto) {
    var list = collect();
    if (!list.length) {
      if (!auto) alert('Не нашла заданий на этой странице.' + NL +
        'Откройте «Задания» → «Домашние задания» и попробуйте снова.');
      return false;
    }
    if (auto && alreadySentToday()) return false;
    window.open(APP + '#hw=' + buildPayload(list), '_blank');
    if (auto) showNote('Домашка уже в «Учусь»');
    return true;
  }

  function showNote(t) {
    var n = document.getElementById(ID + '-note');
    if (!n) {
      n = document.createElement('div');
      n.id = ID + '-note';
      n.style.cssText = 'position:fixed;right:18px;bottom:130px;z-index:2147483647;background:#1c6a5a;color:#fffdf8;' +
        'border-radius:10px;padding:8px 12px;font:600 12.5px system-ui;box-shadow:0 8px 18px -8px rgba(0,0,0,.5)';
      document.body.appendChild(n);
      setTimeout(function () { if (n.parentNode) n.parentNode.removeChild(n); }, 4000);
    }
    n.textContent = t;
  }

  function makeButton() {
    if (document.getElementById(ID)) return;
    var btn = document.createElement('button');
    btn.id = ID;
    btn.type = 'button';
    btn.textContent = 'В Учусь';
    btn.title = 'Перенести задания из дневника в приложение «Учусь» (авто — раз в день)';
    btn.style.cssText = 'position:fixed;right:18px;bottom:82px;z-index:2147483647;background:#1c6a5a;color:#fffdf8;' +
      'border:0;border-radius:14px;padding:12px 18px;font:600 14px/1 system-ui;' +
      'box-shadow:0 10px 24px -8px rgba(0,0,0,.5);cursor:pointer';
    btn.addEventListener('click', function () { push(false); });
    document.body.appendChild(btn);
    // автомат: раз в день при открытии дневника
    push(true);
  }

  if (document.body) makeButton();
  else document.addEventListener('DOMContentLoaded', makeButton);
})();
