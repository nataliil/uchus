/* «Учусь» — кнопка на странице дневника МЭШ.
   Собирает строки с заданиями со страницы и открывает приложение
   с уже разобранным списком. Ничего не отправляет на серверы. */

(function () {
  var APP = 'https://nataliil.github.io/uchus/';
  var ID = 'uchus-mesh-btn';

  if (document.getElementById(ID)) return;

  function linesOfHomework() {
    var re = /(алгебр|геометр|физик|биолог|француз|франц|англ|русск|литератур|истор|обществ|географ|информатик|[0-9]{1,2}[ ]+(январ|феврал|март|апрел|ма|июн|июл|август|сентябр|октябр|ноябр|декабр)|[0-9]{1,2}[./][0-9]{1,2})/i;
    var NL = String.fromCharCode(10);
    var text = document.body ? (document.body.innerText || '') : '';
    var lines = text.split(NL);
    var out = [], seen = {}, total = 0;

    for (var i = 0; i < lines.length; i++) {
      var s = lines[i].replace(/[ \t]+/g, ' ').trim();
      if (!s || s.length > 160 || !re.test(s)) continue;
      if (seen[s]) continue;
      seen[s] = 1;
      out.push(s);
      total += s.length;
      if (total > 3000) break;
    }
    return out;
  }

  function makeButton() {
    var btn = document.createElement('button');
    btn.id = ID;
    btn.type = 'button';
    btn.textContent = 'В Учусь';
    btn.title = 'Перенести задания из дневника в приложение «Учусь»';
    btn.style.cssText = [
      'position:fixed', 'right:18px', 'bottom:82px', 'z-index:2147483647',
      'background:#1c6a5a', 'color:#fffdf8', 'border:0', 'border-radius:14px',
      'padding:12px 18px', 'font:600 14px/1 -apple-system,Segoe UI,Roboto,sans-serif',
      'box-shadow:0 10px 24px -8px rgba(0,0,0,.5)', 'cursor:pointer'
    ].join(';');

    btn.addEventListener('click', function () {
      var list = linesOfHomework();
      if (!list.length) {
        alert('Не нашла заданий на этой странице.' + String.fromCharCode(10) +
              'Откройте «Задания» → «Домашние задания» и нажмите кнопку ещё раз.');
        return;
      }
      var payload = btoa(unescape(encodeURIComponent(list.join(String.fromCharCode(10)))));
      window.open(APP + '#hw=' + payload, '_blank');
    });

    document.body.appendChild(btn);
  }

  // МЭШ — одностраничное приложение: ждём, пока появится тело страницы
  if (document.body) makeButton();
  else document.addEventListener('DOMContentLoaded', makeButton);
})();
