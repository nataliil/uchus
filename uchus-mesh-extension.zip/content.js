/* «Учусь» — автоматический перенос домашки из МЭШ.
   Работает сам: открыли дневник — домашка легла в кабинет и появилась
   на телефоне и компьютере. Пароль не хранит, ничего лишнего не читает. */

(function () {
  var APP = 'https://nishabuh.ru/uchus/';
  var API = 'https://nishabuh.ru/uchus/api.php?code=roman7g';
  var ID = 'uchus-mesh-btn';
  var NL = String.fromCharCode(10);
  var SENT_KEY = 'uchus_last_payload';

  var SUBJECT_RE = /(алгебр|геометр|физическ(ая)? культура|физик|биолог|француз|франц|англ|иностранный|русск|литератур|истор|обществ|географ|информатик|вероятность|статистик)/i;
  var NOISE = [
    /^перемена/i, /^\d{1,2}:\d{2}/, /каб\. ?№/i, /^\d+$/, /^h$/i,
    /материал(ы|а)? к дз/i, /^еще \d+/i, /^ещё \d+/i,
    /дополнительное образование/i, /внеурочная деятельность/i, /^группа /i,
    /раздел переехал/i, /список занятий/i, /^перейти$/i, /^о проекте$/i,
    /польз\. ?соглашение/i, /^\+7 \(\d{3}\)/i, /написать нам/i, /департамент/i,
    /^версия/i, /проектная деятельность/i, /друние занятия/i, /^друние/i,
    /^задания$/, /^домашние задания$/, /^оценки$/, /^учёба$/, /^школа$/, /^счета$/, /^личный кабинет$/i,
    /^день$/, /^шкала времени$/, /^больничный$/, /текущий дневник/i
  ];

  function normSubject(s) {
    var t = String(s || '').replace(/:\s*$/, '').trim();
    return t;
  }

  function collect() {
    var text = document.body ? (document.body.innerText || '') : '';
    var lines = text.split(NL).map(function (s) { return s.replace(/[ \t]+/g, ' ').trim(); });
    var recs = [], cur = null;

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (!line) continue;

      if (SUBJECT_RE.test(line) && !/^(домашнее|не хочу)/i.test(line)) {
        if (cur) recs.push(cur);
        cur = { subject: line, task: [], done: null };
        continue;
      }
      if (/^домашнее задание выполнено/i.test(line)) {
        if (cur) cur.done = true;
        continue;
      }
      if (/^домашнее задание/i.test(line)) {
        if (cur) cur.done = false;
        continue;
      }
      if (/^дополнительное/i.test(line) || /раздел переехал/i.test(line)) break;

      var noise = false;
      for (var j = 0; j < NOISE.length; j++) {
        if (NOISE[j].test(line)) { noise = true; break; }
      }
      if (noise) continue;

      if (cur && line.length > 1) cur.task.push(line);
    }
    if (cur) recs.push(cur);

    return recs
      .filter(function (r) {
        if (r.done === true) return false;
        var t = r.task.join(' ').toLowerCase();
        if (/^не задано\.?$/.test(t) || /^нет дз\.?$/.test(t)) return false;
        return r.task.length;
      })
      .map(function (r) {
        return { s: normSubject(r.subject), text: r.task.join('; ') };
      });
  }

  function todayStr() {
    var d = new Date();
    var m = d.getMonth() + 1, dd = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (dd < 10 ? '0' + dd : dd);
  }

  function send(recs) {
    var body = { hw: recs.map(function (r) { return { s: r.s, text: r.text, due: todayStr() }; }) };
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (r) { return r.json(); }).then(function (j) { return !!j.ok; });
  }

  function payloadKey(recs) {
    return recs.map(function (r) { return r.s + '|' + r.text; }).join(NL).length + '#' + recs.length;
  }

  function alreadySame(recs) {
    var k = payloadKey(recs);
    try {
      if (localStorage.getItem(SENT_KEY) === k) return true;
      localStorage.setItem(SENT_KEY, k);
    } catch (e) {}
    return false;
  }

  function push(auto) {
    var recs = collect();
    if (!recs.length) {
      if (!auto) alert('Не нашла заданий на этой странице.' + NL +
        'Откройте «Задания» → «Домашние задания» и попробуйте снова.');
      return;
    }
    if (auto && alreadySame(recs)) return;

    send(recs).then(function (ok) {
      if (ok) {
        showNote('Домашка ушла в «Учусь» — на телефон и компьютер');
        try { localStorage.setItem(SENT_KEY, payloadKey(recs)); } catch (e) {}
      } else if (!auto) {
        showNote('Не получилось отправить — приложение откроется с домашкой');
        openApp(recs);
      }
    }).catch(function () {
      // сети нет — передаём домашку прямо в приложение через адрес
      openApp(recs);
      if (!auto) showNote('Нет связи с сайтом — домашка открыта в приложении');
    });
  }

  function b64(list) {
    return btoa(unescape(encodeURIComponent(list.join(NL))));
  }
  function openApp(recs) {
    var list = recs.map(function (r) { return r.s + ': ' + r.text; });
    window.open(APP + '#hw=' + b64(list), '_blank');
  }

  function showNote(t) {
    var n = document.getElementById(ID + '-note');
    if (!n) {
      n = document.createElement('div');
      n.id = ID + '-note';
      n.style.cssText = 'position:fixed;right:18px;bottom:130px;z-index:2147483647;background:#1c6a5a;color:#fffdf8;' +
        'border-radius:10px;padding:8px 12px;font:600 12.5px system-ui;box-shadow:0 8px 18px -8px rgba(0,0,0,.5)';
      document.body.appendChild(n);
    }
    n.textContent = t;
    clearTimeout(showNote._t);
    showNote._t = setTimeout(function () { if (n.parentNode) n.parentNode.removeChild(n); }, 4000);
  }

  function makeButton() {
    if (document.getElementById(ID)) return;
    var btn = document.createElement('button');
    btn.id = ID;
    btn.type = 'button';
    btn.textContent = 'В Учусь';
    btn.title = 'Открыть приложение «Учусь» (домашка переносится сама)';
    btn.style.cssText = 'position:fixed;right:18px;bottom:82px;z-index:2147483647;background:#1c6a5a;color:#fffdf8;' +
      'border:0;border-radius:14px;padding:12px 18px;font:600 14px/1 system-ui;' +
      'box-shadow:0 10px 24px -8px rgba(0,0,0,.5);cursor:pointer';
    btn.addEventListener('click', function () { window.open(APP, '_blank'); });
    document.body.appendChild(btn);

    push(true);
    // дневник подгружается постепенно — повторим, когда текст обновится
    var t = null;
    var obs = new MutationObserver(function () {
      clearTimeout(t);
      t = setTimeout(function () { push(true); }, 2500);
    });
    try { obs.observe(document.body, { childList: true, subtree: true }); } catch (e) {}
  }

  if (document.body) makeButton();
  else document.addEventListener('DOMContentLoaded', makeButton);
})();
